package com.rozdoum.socialcomponents.utils;

import com.bumptech.glide.annotation.GlideModule;
import com.bumptech.glide.module.AppGlideModule;

/**
 * Created by Alexey on 15.02.18.
 */

@GlideModule
public final class CustomAppGlideModule extends AppGlideModule {
}
